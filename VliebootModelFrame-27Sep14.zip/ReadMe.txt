Product: Vlieboot Model Frame, September 2014

Designer: Zombie Cat, http://zombie-cat.org/

Support:  http://forums.obrary.com/category/designs/vlieboot-model-frame

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
Here's a teaching tool for students learning about the age of exploration.  The age of exploration was fueled by the development of sea-worthy boats like this one. This design gives you the frame for a model of one of the more famous "vlieboot" vessels made, the Half Moon (or Halve Maen as the Dutch called it), that was captained by Henry Hudson. This is similar in design to the Carracks that Columbus and Magellan sailed.